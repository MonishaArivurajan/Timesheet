from rest_framework import serializers
from .models import MyUser, EmployeeDetail, TimeSheet

class MyUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = MyUser
        fields = ['id', 'email', 'userid', 'name', 'phone_number', 'personstatus', 'is_active', 'is_admin']

class EmployeeDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeDetail
        fields = ['id', 'employee', 'date', 'comments', 'lead_approval', 'manager_approval']

class TimeSheetSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimeSheet
        fields = ['id', 'employee', 'week', 'mon', 'tue', 'wed', 'thu', 'fri', 'total', 'lead_approval', 'manager_approval']
