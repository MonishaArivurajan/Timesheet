from rest_framework import viewsets, permissions
from .models import MyUser, EmployeeDetail, TimeSheet
from .serializers import MyUserSerializer, EmployeeDetailSerializer, TimeSheetSerializer

class MyUserViewSet(viewsets.ModelViewSet):
    queryset = MyUser.objects.all()
    serializer_class = MyUserSerializer
    permission_classes = [permissions.IsAuthenticated]

class EmployeeDetailViewSet(viewsets.ModelViewSet):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    permission_classes = [permissions.IsAuthenticated]

class TimeSheetViewSet(viewsets.ModelViewSet):
    queryset = TimeSheet.objects.all()
    serializer_class = TimeSheetSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        timesheet = serializer.save()
        self.calculate_leave_days(timesheet)

    def perform_update(self, serializer):
        timesheet = serializer.save()
        self.calculate_leave_days(timesheet)

    def calculate_leave_days(self, timesheet):
        leave_days = 0
        days = [timesheet.mon, timesheet.tue, timesheet.wed, timesheet.thu, timesheet.fri]
        for day in days:
            if day == 0:
                leave_days += 1
        timesheet.total = sum(days)
        timesheet.save()
