from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MyUserViewSet, EmployeeDetailViewSet, TimeSheetViewSet

router = DefaultRouter()
router.register(r'users', MyUserViewSet)
router.register(r'employee_details', EmployeeDetailViewSet)
router.register(r'timesheets', TimeSheetViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
