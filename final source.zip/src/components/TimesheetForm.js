import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TimesheetForm.css';

const TimesheetForm = () => {
  const [userid, setUserid] = useState(''); 
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    id: '', // Employee ID (from localStorage or API)
    week: '',
    mon: '',
    tue: '',
    wed: '',
    thu: '',
    fri: '',
    total: '',
    lead_approval: 'Pending',
  });
  const [submittedData, setSubmittedData] = useState(null);
  const [timesheets, setTimesheets] = useState([]);

  useEffect(() => {
    const fetchTimesheets = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/api/timesheet/');
        setTimesheets(response.data);
      } catch (error) {
        console.error('Error fetching timesheets:', error);
      }
    };

    fetchTimesheets();
  }, []);

  useEffect(() => {
    const storedUserid = localStorage.getItem('userid');
    if (storedUserid) {
      setFormData((prevData) => ({
        ...prevData,
        id: storedUserid,
      }));
    }
  }, []);

  useEffect(() => {
    const storedUserid = localStorage.getItem('userid');
    const storedPersonstatus = localStorage.getItem('personstatus');
    console.log('Fetched userid:', storedUserid);
    console.log('Fetched personstatus:', storedPersonstatus);
    if (storedUserid) {
      setUserid(storedUserid);
    }
    const totalHours =
      parseFloat(formData.mon || 0) +
      parseFloat(formData.tue || 0) +
      parseFloat(formData.wed || 0) +
      parseFloat(formData.thu || 0) +
      parseFloat(formData.fri || 0);
    setFormData((prevData) => ({
      ...prevData,
      total: totalHours,
    }));
  }, [formData.mon, formData.tue, formData.wed, formData.thu, formData.fri]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/timesheet/add/', formData);
      setSubmittedData(response.data);
      setShowForm(false);
      setTimesheets([...timesheets, response.data]);
    } catch (error) {
      console.error('Error submitting timesheet:', error);
    }
  };

  const handlePreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() - 1)));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.setMonth(currentMonth.getMonth() + 1)));
  };

  const toggleForm = () => {
    setShowForm(!showForm);
  };

  const togglePopup = (data) => {
    setSubmittedData(submittedData === data ? null : data);
  };

  const renderCalendar = () => {
    const startOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
    const endOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0);
    const daysInMonth = endOfMonth.getDate();
    const startDay = startOfMonth.getDay();

    const calendarDays = [];

    // Days of the week headers
    const weekDays = ['Sun','Mon','Tue','Wed','Thu', 'Fri','Sat'];
    weekDays.forEach(day => {
      calendarDays.push(
        <div key={day} className="calendar-header-day">{day}</div>
      );
    });

    // Empty placeholders for days before the start of the month
    for (let i = 0; i < startDay; i++) {
      calendarDays.push(<div key={`empty-${i}`} className="calendar-day"></div>);
    }

    // Days of the month with timesheet or add button
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      const timesheet = timesheets.find((ts) => new Date(ts.week).toDateString() === date.toDateString());
      const isMonday = date.getDay() === 1; // Check if the day is Monday

      calendarDays.push(
        <div key={day} className="button">
          <div>{day}</div>
          {timesheet ? (
            <div className="circle" onClick={() => togglePopup(timesheet)}>
              {timesheet.total}
            </div>
          ) : (
            isMonday && (
              <button className="add-button" onClick={toggleForm}>+</button>
            )
          )}
        </div>
      );
    }

    return <div className="calendar">{calendarDays}</div>;
  };

  return (
    
    <div className="container">
      <div>
      <h2>Update Timesheet</h2>
    </div>
      <div className="calendar-header">
        <button className="button" onClick={handlePreviousMonth}>Previous</button>
        <div className="button2">{currentMonth.toLocaleString('default', { month: 'long' })} {currentMonth.getFullYear()}</div>
        <button className="button" onClick={handleNextMonth}>Next</button>
      </div>
      
      {renderCalendar()}
      {showForm && (
        <form className="form-popup" onSubmit={handleSubmit}>
          <div>
            <label>Employee</label>
            <input
              type="text"
              name="employee"
              value={userid}
              readOnly
            />
          </div>
          <div>
            <label>Week</label>
            <input
              type="text"
              name="week"
              value={formData.week}
              onChange={handleChange}
            />
          </div>
          <div>
            <label>Mon</label>
            <div>
            <input
              type="number"
              name="mon"
              value={formData.mon}
              onChange={handleChange}
            />
            </div>
          </div>
          <div>
            <label>Tue</label>
            <div>
            <input
              type="number"
              name="tue"
              value={formData.tue}
              onChange={handleChange}
            />
            </div>
          </div>
          <div>
            <label>Wed</label>
            <div>
            <input
              type="number"
              name="wed"
              value={formData.wed}
              onChange={handleChange}
            />
            </div>
          </div>
          <div>
            <label>Thu</label>
            <div>
            <input
              type="number"
              name="thu"
              value={formData.thu}
              onChange={handleChange}
            />
            </div>
          </div>
          <div>
            <label>Fri</label>
            <div>
            <input
              type="number"
              name="fri"
              value={formData.fri}
              onChange={handleChange}
            />
            </div>
          </div>
          <div>
            <label>Total</label>
            <div>
            <input
              type="number"
              name="total"
              value={formData.total}
              readOnly
            />
            </div>
          </div>
          <button type="submit" className="button1">Submit</button>
          <button type="button" className="button cancel-button" onClick={() => setShowForm(false)}>Cancel</button>
        </form>
      )}
      {submittedData && (
        <div className="submitted-data">
          <h3>Submitted Timesheet</h3>
          <p>Employee: {submittedData.employee}</p>
          <p>Week: {submittedData.week}</p>
          <p>Monday: {submittedData.mon}</p>
          <p>Tuesday: {submittedData.tue}</p>
          <p>Wednesday: {submittedData.wed}</p>
          <p>Thursday: {submittedData.thu}</p>
          <p>Friday: {submittedData.fri}</p>
          <p>Total Hours: {submittedData.total}</p>
          <p>Lead Approval: {submittedData.lead_approval}</p>
          <button className="button cancel-button" onClick={() => togglePopup(null)}>Cancel</button>
          
        </div>
      )}
    </div>
    
  );
};

export default TimesheetForm;
