import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TimesheetTable.css'; // Import the CSS file

const TimesheetTable = () => {
  const [timesheets, setTimesheets] = useState([]);

  useEffect(() => {
    const fetchTimesheets = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/api/timesheet/');
        setTimesheets(response.data);
      } catch (error) {
        console.error('Error fetching timesheets:', error);
      }
    };

    fetchTimesheets();
  }, []);

  return (
    <div className="table-container">
      <h2>Timesheet Data</h2>
      <table>
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Week</th>
            <th>Monday</th>
            <th>Tuesday</th>
            <th>Wednesday</th>
            <th>Thursday</th>
            <th>Friday</th>
            <th>Total Hours</th>
            <th>Lead Approval</th>
          </tr>
        </thead>
        <tbody>
          {timesheets.map((timesheet) => (
            <tr key={timesheet.id}>
              <td data-label="Employee ID">{timesheet.employee}</td>
              <td data-label="Week">{timesheet.week}</td>
              <td data-label="Monday">{timesheet.mon}</td>
              <td data-label="Tuesday">{timesheet.tue}</td>
              <td data-label="Wednesday">{timesheet.wed}</td>
              <td data-label="Thursday">{timesheet.thu}</td>
              <td data-label="Friday">{timesheet.fri}</td>
              <td data-label="Total Hours">{timesheet.total}</td>
              <td data-label="Lead Approval">{timesheet.lead_approval}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TimesheetTable;
