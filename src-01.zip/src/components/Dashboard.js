import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import CalendarTable from './CalendarTable';
import TeamTable from './TeamTable';
import Profile from './Profile';
import HomePage from './HomePage';
import UpdateTimesheet from './UpdateTimesheet';
import ViewTimesheet from './ViewTimesheet';
import axios from 'axios';

const Dashboard = () => {
  const [empid, setEmpid] = useState(null);
  const [employeeName, setEmployeeName] = useState('');

  useEffect(() => {
    if (empid) {
      axios.get(`http://127.0.0.1:8000/api/employee-details/${empid}`)
        .then(response => {
          setEmployeeName(response.data.employee_name);
        })
        .catch(error => {
          console.error('There was an error fetching the employee details!', error);
        });
    }
  }, [empid]);

  return (
    <div className="dashboard-container">
      <div className="main-content">
        <Routes>
          <Route path="profile" element={<HomePage  />} />
          <Route path="update-timesheet" element={<UpdateTimesheet />} />
          <Route path="view-timesheet" element={<ViewTimesheet />} />
          <Route path="calendar-table" element={<CalendarTable empid={empid}  />} />
          <Route path="teamtable" element={<TeamTable />} />
        </Routes>
      </div>
    </div>
  );
};

export default Dashboard;

