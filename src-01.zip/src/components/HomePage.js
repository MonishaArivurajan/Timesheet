import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import 'chart.js/auto';
import './HomePage.css'; // Ensure you have a CSS file for styling

const HomePage = ({ employeeName, empId, email }) => {
  const [percentage, setPercentage] = useState(80); // Default percentage
  const [leaveDays, setLeaveDays] = useState(0); // State for leave days

  useEffect(() => {
    if (empId) {
      axios.get(`http://127.0.0.1:8000/api/get-employee-details/${empId}/`)
        .then(response => {
          console.log(response.data); // Log API response
          const joiningDate = new Date(response.data.joining_date);
          const workDates = response.data.work_dates.map(date => new Date(date));

          const calculateLeaveDays = (joiningDate, workDates) => {
            const today = new Date();
            let leaveDays = 0;
            for (let d = new Date(joiningDate); d <= today; d.setDate(d.getDate() + 1)) {
              // Exclude Sundays
              if (d.getDay() !== 0) {
                const isWorkDay = workDates.some(workDate => 
                  workDate.getFullYear() === d.getFullYear() &&
                  workDate.getMonth() === d.getMonth() &&
                  workDate.getDate() === d.getDate()
                );
                console.log(`Date: ${d}, isWorkDay: ${isWorkDay}`); // Log date and workday status
                if (!isWorkDay) {
                  leaveDays++;
                }
              }
            }
            return leaveDays;
          };

          const leaveDays = calculateLeaveDays(joiningDate, workDates);
          setLeaveDays(leaveDays);
        })
        .catch(error => {
          console.error('There was an error fetching the leave days!', error);
        });
    }
  }, [empId]);

  // Dummy data for the bar chart
  const data = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'August'],
    datasets: [
      {
        label: 'Attendance Percentage',
        data: [65, 59, 80, 81, 56, 55, 5],
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="home-page">
      <h1>Welcome, {employeeName} <span role="img" aria-label="smile">😊</span></h1>
      <div className="content-container">
        <div className="chart-container">
          <Bar data={data} options={options} />
        </div>
        <div className="circular-progress-container">
          <div className="circular-progress">
            <div className="circle">
              <div className="mask full" style={{ transform: `rotate(${1.8 * percentage}deg)` }}>
                <div className="fill" style={{ transform: `rotate(${1.8 * percentage}deg)` }}></div>
              </div>
              <div className="mask half">
                <div className="fill" style={{ transform: `rotate(${1.8 * percentage}deg)` }}></div>
              </div>
              <div className="inside-circle">{percentage}%</div>
            </div>
          </div>
        </div>
        <div className="leave-days-container">
          <h2>Total Leave Days: {leaveDays}</h2>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
