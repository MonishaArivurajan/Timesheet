import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const EmployeeDetail = () => {
  const { empId } = useParams();
  const [employeeDetail, setEmployeeDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (empId) {
      axios.get(`http://127.0.0.1:8000/api/employee-details/${empId}/`)
        .then(response => {
          setEmployeeDetail(response.data);
          setLoading(false);
        })
        .catch(error => {
          setError('There was an error fetching the employee details.');
          setLoading(false);
        });
    }
  }, [empId]);

  const handleApprovalChange = (empId, status) => {
    axios.patch(`http://127.0.0.1:8000/api/employee-details/${empId}/`, {
      manager_approval: status
    })
    .then(response => {
      setEmployeeDetail(prevState => ({
        ...prevState,
        manager_approval: status
      }));
    })
    .catch(error => {
      console.error('There was an error updating the approval status!', error.response ? error.response.data : error.message);
      setError('There was an error updating the approval status.');
    });
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div>
      <h2>Employee Details</h2>
      <table>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Emp ID</th>
            <th>Date</th> 
            <th>Start Time</th>
            <th>End Time</th>
            <th>Project Name</th>
            
            <th>Total Worked Hours</th>
            <th>Lead Approval</th>
            <th>Manager Approval</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{employeeDetail.employee_name}</td>
            <td>{employeeDetail.emp_id}</td> 
            <td>{employeeDetail.date}</td>
            <td>{employeeDetail.start_time}</td>
            <td>{employeeDetail.end_time}</td>
            <td>{employeeDetail.project_name}</td>
            
            <td>{employeeDetail.total_hours_worked}</td>
            <td>{employeeDetail.lead_approval}</td>
            <td>
              {employeeDetail.manager_approval}
              <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'approved')}>Approve</button>
              <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'rejected')}>Reject</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeDetail;
