import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClock, faHome, faFileAlt, faChartBar, faTasks, faStar, faUsers, faDollarSign, faCogs } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import './Sidebar.css';

const Sidebar = ({ onCalendarClick }) => {
  return (
    <div className="sidebar">
      <div className="sidebar-title">
        <FontAwesomeIcon icon={faClock} />
        <span>TIME TITANS</span>
      </div>
      <div className="sidebar-search">
        <input type="text" placeholder="Search..." />
      </div>
      <div className="sidebar-menu">
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faHome} />
          <span><Link to="/home" className="sidebar-link">Home Page</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faFileAlt} />
          <span>All Pages</span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faChartBar} />
          <span>Reports</span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faTasks} />
          <span><Link to="/calendar" className="sidebar-link">Task</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faStar} />
          <span><Link to="/teamtable" className="sidebar-link">Team</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faUsers} />
          <span><Link to="/employees" className="sidebar-link">Employees</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faDollarSign} />
          <span>Revenue</span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faCogs} />
          <span>Settings</span>
        </div>
      </div>
      <button className="timesheet-button" onClick={onCalendarClick}>TIMESHEET</button>
    </div>
  );
};

export default Sidebar;

