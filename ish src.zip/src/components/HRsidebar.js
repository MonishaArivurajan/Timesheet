import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faUsers, faClock } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import './Sidebar.css';

const HRsidebar = ({ onCalendarClick }) => {
  return (
    <div className="sidebar">
      <div className="sidebar-title">
        <FontAwesomeIcon icon={faClock} />
        <span>HR Dashboard</span>
      </div>
      <div className="sidebar-item">
          <FontAwesomeIcon icon={faHome} />
          <span><Link to="/hr-dashboard/homes" className="sidebar-link">Home</Link></span>
        </div>
      
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faUsers} />
          <span><Link to="/hr-dashboard/home" className="sidebar-link">Employee List</Link></span>
        </div>
      
      <button className="timesheet-button" onClick={onCalendarClick}>TIMESHEET</button>
    </div>
  );
};

export default HRsidebar;
