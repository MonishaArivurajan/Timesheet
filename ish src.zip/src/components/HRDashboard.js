// src/components/HRDashboard.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const HRDashboard = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [leaveDays, setLeaveDays] = useState(0);

  useEffect(() => {
    // Fetch the employee list
    axios.get('http://127.0.0.1:8000/api/employee-details/')
      .then(response => {
        setEmployees(response.data);
      })
      .catch(error => {
        console.error('Error fetching employees:', error);
      });
  }, []);

  const handleEmployeeClick = (empId) => {
    setSelectedEmployee(empId);
    // Fetch leave days
    axios.get(`http://127.0.0.1:8000/api/employee-details/${empId}/`)
      .then(response => {
        const timesheetData = response.data.timesheet; // Assuming `timesheet` is an array of timesheet data
        calculateLeaveDays(timesheetData);
      })
      .catch(error => {
        console.error('Error fetching employee details:', error);
      });
  };

  const calculateLeaveDays = (timesheetData) => {
    // Calculate leave days logic here
    const getSundaysInMonth = (year, month) => {
      let date = new Date(year, month, 1);
      const sundays = [];
      while (date.getMonth() === month) {
        if (date.getDay() === 0) { // Sunday
          sundays.push(date.getDate());
        }
        date.setDate(date.getDate() + 1);
      }
      return sundays;
    };

    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth(); // 0-indexed
    const sundays = getSundaysInMonth(currentYear, currentMonth);
    const totalDays = new Date(currentYear, currentMonth + 1, 0).getDate(); // Days in the current month
    const workingDays = totalDays - sundays.length;
    const filledDays = timesheetData.map(entry => new Date(entry.date).getDate());
    const uniqueFilledDays = new Set(filledDays);
    const filledWorkingDays = [...uniqueFilledDays].filter(day => !sundays.includes(day)).length;
    const leaveDaysCount = workingDays - filledWorkingDays;
    setLeaveDays(leaveDaysCount);
  };

  return (
    <div className="hr-dashboard">
      
      <div className="content">
        <div className="employee-list">
          <h3>Employee Names</h3>
          <ul>
            {employees.map(employee => (
              <li key={employee.emp_id} onClick={() => handleEmployeeClick(employee.emp_id)}>
                {employee.employee_name}
              </li>
            ))}
          </ul>
        </div>
        {selectedEmployee && (
          <div className="employee-popup">
            <p>Welcome, {selectedEmployee}</p>
            <p>Leave Days: {leaveDays}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default HRDashboard;
