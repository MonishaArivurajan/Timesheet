import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './HomePage.css';
const HomePage = () => {
  const [leaveDays, setLeaveDays] = useState(0);
  const [error, setError] = useState(null);
  const calculateLeaveDays = (timesheetData) => {
    const getSundaysInMonth = (year, month) => {
      let date = new Date(year, month, 1);
      const sundays = [];
      while (date.getMonth() === month) {
        if (date.getDay() === 0) { // Sunday
          sundays.push(date.getDate());
        }
        date.setDate(date.getDate() + 1);
      }
      return sundays;
    };
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth(); // 0-indexed
    const sundays = getSundaysInMonth(currentYear, currentMonth);
    const totalDays = new Date(currentYear, currentMonth + 1, 0).getDate(); // Days in the current month
    const workingDays = totalDays - sundays.length;
    const filledDays = timesheetData.map(entry => new Date(entry.date).getDate());
    const uniqueFilledDays = new Set(filledDays);
    const filledWorkingDays = [...uniqueFilledDays].filter(day => !sundays.includes(day)).length;
    const leaveDaysCount = workingDays - filledWorkingDays;
    setLeaveDays(leaveDaysCount);
  };
  useEffect(() => {
    const fetchTimesheetData = () => {
      axios.get('http://127.0.0.1:8000/api/employee-details/')
        .then(response => {
          const timesheetData = response.data;
          calculateLeaveDays(timesheetData);
          setError(null);
        })
        .catch(error => {
          console.error('Error fetching timesheet data:', error);
          if (error.response) {
            setError(`Failed to fetch timesheet data: ${JSON.stringify(error.response.data)}`);
          } else if (error.request) {
            setError('Failed to fetch timesheet data: No response from server');
          } else {
            setError(`Failed to fetch timesheet data: ${error.message}`);
          }
        });
    };
    fetchTimesheetData();
  }, []);
  return (
    <div className="leave-days-container">
      <h2>Leave Days</h2>
      {error && <p className="error">{error}</p>}
      <p>Total Leave Days: {leaveDays}</p>
    </div>
  );
};
export default HomePage;