# serializers.py
from rest_framework import serializers
from .models import MyUser, EmployeeDetail, TimeSheet

class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = MyUser
        fields = ['email', 'userid', 'name', 'phone_number', 'password']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = MyUser.objects.create_user(
            email=validated_data['email'],
            userid=validated_data['userid'],
            name=validated_data['name'],
            phone_number=validated_data['phone_number'],
            password=validated_data['password']
        )
        return user

class LoginSerializer(serializers.Serializer):
    userid = serializers.CharField()
    password = serializers.CharField()

class MyUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = MyUser
        fields = ['userid', 'name', 'email', 'phone_number']

class EmployeeDetailSerializer(serializers.ModelSerializer):
    employee = MyUserSerializer()

    class Meta:
        model = EmployeeDetail
        fields = ['employee', 'date', 'comments', 'lead_approval','manager_approval']

class TimeSheetSerializer(serializers.ModelSerializer):
    employee = MyUserSerializer()

    class Meta:
        model = TimeSheet
        fields = ['id','employee', 'week', 'mon', 'tue', 'wed', 'thu', 'fri', 'total', 'lead_approval','manager_approval']
