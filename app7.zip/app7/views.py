from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from .models import MyUser, EmployeeDetail, TimeSheet
from .serializers import *


class RegisterView(CreateAPIView):
    queryset = MyUser.objects.all()
    serializer_class = RegisterSerializer

class LoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        userid = serializer.validated_data['userid']
        password = serializer.validated_data['password']
        print("Test: ",userid,password)

        user = MyUser.objects.filter(userid=userid, password=password).first()
        print(user)

        if user is not None:
            personstatus = getattr(user, 'personstatus', None)
            print(personstatus)
            response_data = {
                'userid': userid,
                'personstatus': personstatus
            }
            if personstatus == 'Employee':
                response_data['redirect_url'] = '/employee-dashboard/'
            elif personstatus == 'Lead':
                response_data['redirect_url'] = '/lead-dashboard/'
            elif personstatus == 'Manager':
                response_data['redirect_url'] = '/manager-dashboard/'
            else:
                return Response({'error': 'Unknown person status'}, status=status.HTTP_400_BAD_REQUEST)

            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

        # Fallback response to ensure every code path returns a Response
        return Response({'error': 'An unexpected error occurred'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
class ChangePasswordView(APIView):
    def post(self, request):
        userid = request.data.get('userid')
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')

        user = MyUser.objects.filter(userid=userid).first()
        if user and user.check_password(old_password):
            user.set_password(new_password)
            user.save()
            return Response({'status': 'password changed'}, status=status.HTTP_200_OK)
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

# class EmployeeDetailView(APIView):
#     def get(self, request):
#         employee_id = request.query_params.get('employee_id')
#         print(employee_id)
#         if employee_id:
#             try:
#                 employee = MyUser.objects.get(userid=employee_id)
#                 print(employee)
#                 employee_details = MyUser.objects.filter(userid=employee).first()
#                 print(employee_details)
#                 if employee_details.exists():
#                     serializer = EmployeeDetailSerializer(employee_details, many=True)
#                     return Response(serializer.data, status=status.HTTP_200_OK)
#                 return Response({'error': 'Employee detail not found'}, status=status.HTTP_404_NOT_FOUND)
#             except MyUser.DoesNotExist:
#                 return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
#         else:
#             employees = MyUser.objects.all()
#             serializer = MyUserSerializer(employees, many=True)
#             return Response(serializer.data, status=status.HTTP_200_OK)


class EmployeeDetailView(APIView):
    def get(self, request):
        employee_id = request.query_params.get('employee_id')
        print(employee_id)
        if employee_id:
            try:
                print(employee_id)
                employee = MyUser.objects.get(userid=employee_id)
                print(employee)
                employee_details = EmployeeDetail.objects.filter(employee=employee).first()
                print(employee_details)
                if employee_details:
                    print(EmployeeDetail)
                    serializer = EmployeeDetailSerializer(employee_details)
                    return Response(serializer.data, status=status.HTTP_200_OK)
                return Response({'error': 'Employee detail not found'}, status=status.HTTP_404_NOT_FOUND)
            except MyUser.DoesNotExist:
                return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        else:
            employees = MyUser.objects.all()
            serializer = MyUserSerializer(employees, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)


class TimeSheetViewSet(viewsets.ModelViewSet):
    queryset = TimeSheet.objects.all()
    serializer_class = TimeSheetSerializer
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.lead_approval = 'Approved'
        timesheet.save()
        return Response({'status': 'Timesheet approved by Lead'}, status=status.HTTP_200_OK)
   
    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.lead_approval = 'Rejected'
        timesheet.save()
        return Response({'status': 'Timesheet rejected by Lead'}, status=status.HTTP_200_OK)
    @action(detail=True, methods=['post'])
    def manager_approve(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.manager_approval = 'Approved'
        timesheet.save()
        return Response({'status': 'Timesheet approved by Manager'}, status=status.HTTP_200_OK)
    
    
    @action(detail=True, methods=['post'])
    def manager_reject(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.manager_approval = 'Rejected'
        timesheet.save()
        return Response({'status': 'Timesheet rejected by Manager'}, status=status.HTTP_200_OK)
