import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TeamleaderSheetForm = () => {
    const [formData, setFormData] = useState({
        project_name: '',
        module_name: '',
        userid: ''
    });
    const [managerSheets, setManagerSheets] = useState([]);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [loading, setLoading] = useState(true);

    // Fetch user status and manager sheets
    useEffect(() => {
        const fetchData = async () => {
            try {
                // Fetch user status
                const userResponse = await axios.get('http://127.0.0.1:8000/api/employee/');
                setFormData(prev => ({ ...prev, userid: userResponse.data.id }));

                // Fetch manager sheets
                const sheetsResponse = await axios.get('http://127.0.0.1:8000/api/manager/');
                setManagerSheets(sheetsResponse.data);
            } catch (error) {
                console.error('Error fetching data:', error);
                setError('Error fetching data.');
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);

        try {
            await axios.post('http://127.0.0.1:8000/api/teamleader/post', formData);
            setSuccess('Form submitted successfully.');
            setFormData({
                project_name: '',
                module_name: '',
                userid: ''
            });
            setError('');
        } catch (err) {
            setError('Error submitting form.');
            console.error('Error submitting form:', err);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (loading) return <p>Loading...</p>;

    return (
        <div>
            <h1>Submit Teamleader Sheet</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {success && <p style={{ color: 'green' }}>{success}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>User ID:</label>
                    <input
                        type="text"
                        name="userid"
                        value={formData.userid}
                        
                    />
                </div>
                <div>
                    <label>Project Name:</label>
                    <select
                        name="project_name"
                        value={formData.project_name}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select a project</option>
                        {managerSheets.map(sheet => (
                            <option key={sheet.id} value={sheet.id}>
                                {sheet.project_name}
                            </option>
                        ))}
                    </select>
                </div>
                <div>
                    <label>Module Name:</label>
                    <input
                        type="text"
                        name="module_name"
                        value={formData.module_name}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'Submitting...' : 'Submit'}
                </button>
            </form>
        </div>
    );
};

export default TeamleaderSheetForm;
