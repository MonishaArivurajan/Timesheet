import React, { useState } from 'react';
import axios from 'axios';

const CalculateSalary = () => {
  const [timesheetId, setTimesheetId] = useState('');
  const [salary, setSalary] = useState(null);
  const [error, setError] = useState(null);

  const handleCalculateSalary = async () => {
    try {
      const response = await axios.post(`http://127.0.0.1:8000/api/calculate-salary/${timesheetId}`);
      setSalary(response.data.salary);
    } catch (error) {
      setError('Failed to calculate salary');
    }
  };

  return (
    <div>
      <h2>Calculate Employee Salary</h2>
      <input
        type="text"
        placeholder="Enter Timesheet ID"
        value={timesheetId}
        onChange={(e) => setTimesheetId(e.target.value)}
      />
      <button onClick={handleCalculateSalary}><b>Calculate Salary</b></button>
      {salary && <p>Calculated Salary: ${salary}</p>}
      {error && <p>{error}</p>}
    </div>
  );
};

export default CalculateSalary;
