export default {
    API_URL: "http://127.0.0.1:8000/api/",
    CRU_URL : "http://127.0.0.1:8000"
};