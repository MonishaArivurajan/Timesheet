# myapp/admin.py

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import Group
from .models import User, EmployeeDetail

class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'emp_id', 'is_admin', 'position', 'joining_date', 'Time_stamp')
    list_filter = ('is_admin','position')
    fieldsets = (
        (None, {'fields': ('username', 'email', 'emp_id', 'password')}),
        ('Personal info', {'fields': ('position', 'joining_date','Time_stamp',)}),
        ('Permissions', {'fields': ('is_admin',)}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'emp_id','position', 'joining_date', 'password1', 'password2'),
        }),
    )
    search_fields = ('username', 'email', 'emp_id','position')
    ordering = ('username',)
    filter_horizontal = ()

class EmployeeDetailAdmin(admin.ModelAdmin):
    list_display = ('employee_name', 'emp_id', 'project_name', 'date', 'total_hours_worked', 'lead_approval', 'manager_approval')
    list_filter = ('project_name', 'date', 'lead_approval', 'manager_approval')
    search_fields = ('employee_name', 'emp_id', 'project_name')
    ordering = ('date',)

admin.site.register(User, UserAdmin)
admin.site.register(EmployeeDetail, EmployeeDetailAdmin)

# Unregister the Group model from admin as it's not used
admin.site.unregister(Group)
