from django.core.management.base import BaseCommand
from app8.models import Project

class Command(BaseCommand):
    help = 'Initialize projects'

    def handle(self, *args, **kwargs):
        projects = ['Time Sheet Management Project', 'ABC Project']
        for project_name in projects:
            Project.objects.get_or_create(name=project_name)
        self.stdout.write(self.style.SUCCESS('Projects initialized successfully'))
