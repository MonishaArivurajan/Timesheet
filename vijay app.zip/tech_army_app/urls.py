from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import RegisterView, LoginView, ChangePasswordView, EmployeeDetailView, TimeSheetViewSet, ManagerSheetViewSet, TeamleaderSheetViewSet


router = DefaultRouter()
router.register(r'timesheet', TimeSheetViewSet)
router.register(r'manager', ManagerSheetViewSet)
router.register(r'teamleader', TeamleaderSheetViewSet)


urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('change-password/', ChangePasswordView.as_view(), name='change-password'),
    path('employee/', EmployeeDetailView.as_view(), name='employee-detail'),
    path('calculate-salary/<int:pk>/', TimeSheetViewSet.as_view({'post': 'calculate_salary'}), name='calculate-salary'),
    path('', include(router.urls)),  # This includes the router-generated URLs
]
