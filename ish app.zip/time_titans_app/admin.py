from django.contrib import admin
from .models import User, EmployeeDetail, Project

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'emp_id', 'position', 'joining_date', 'is_active', 'is_admin')
    search_fields = ('username', 'email', 'emp_id')

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('emp_id', 'project_name', 'project_module', 'status', 'timestamp')
    search_fields = ('emp_id__emp_id', 'project_name', 'project_module')

@admin.register(EmployeeDetail)
class EmployeeDetailAdmin(admin.ModelAdmin):
    list_display = ('emp_id', 'employee_name', 'start_time', 'end_time', 'project_name', 'date', 'total_hours_worked', 'lead_approval', 'manager_approval')
    search_fields = ('emp_id__emp_id', 'employee_name', 'project_name')
    list_filter = ('lead_approval', 'manager_approval')