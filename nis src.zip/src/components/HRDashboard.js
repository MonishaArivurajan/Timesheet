// src/components/HRDashboard.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './HRDashboard.css';

const HRDashboard = ({}) => {
  const [employees, setEmployees] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/employee-details/')
      .then(response => {
        setEmployees(response.data);
      })
      .catch(error => {
        console.error('Error fetching employees:', error);
        setError('Failed to fetch employees.');
      });
  }, []);

  const handleEmployeeClick = (empId) => {
    navigate(`/hr-dashboard/Emp/${empId}`);
  };

  return (
    <div className="hr-dashboard">
      <div className="content">
        <div className="employee-list"><br></br>
        <h3>Employee List</h3>
        <input
        type="text"
        placeholder="Search by name"
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)} // Update the search term
        style={{ marginBottom: '10px', padding: '5px', width: '100%' }}
      />
        
          <ul>
            {employees.map(employee => (
              <li key={employee.emp_id} onClick={() => handleEmployeeClick(employee.emp_id)}>
                {employee.employee_name}
              </li>
            ))}
          </ul>
        </div>
        {error && <p className="error-message">{error}</p>}
      </div>
    </div>
  );
};

export default HRDashboard;
