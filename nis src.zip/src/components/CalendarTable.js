import React, { useState } from 'react';
import './CalendarTable.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSmile } from '@fortawesome/free-solid-svg-icons';

const CalendarTable = ({ empid, employeeName }) => {
  const rows = Array.from({ length: 6 });
  const columns = Array.from({ length: 5 });
  const [hours, setHours] = useState(Array(30).fill([]));

  const getRandomColor = () => {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  };

  const addHours = (index, newHours) => {
    const updatedHours = [...hours];
    updatedHours[index] = [
      ...updatedHours[index],
      { hours: newHours, color: getRandomColor() }
    ];
    setHours(updatedHours);
  };

  const isWeekend = (index) => {
    const dayOfWeek = (index + 1) % 7;
    return dayOfWeek === 0 || dayOfWeek === 6;
  };

  return (
    <div className="calendar-table">
      <div className="header">
       
        <span>Employee ID: {empid}</span>
        <span>Month: July</span>
        <span>Year: 2024</span>
      </div>
      <table>
        <tbody>
          {rows.map((_, rowIndex) => (
            <tr key={rowIndex}>
              {columns.map((_, colIndex) => {
                const index = rowIndex * 5 + colIndex;
                return (
                  <td key={colIndex}>
                    <div className="cell-content">
                      <span className="date">{index + 1}</span>
                      <button
                        className="add-hours"
                        onClick={() => {
                          const newHours = prompt('Enter worked hours:');
                          if (newHours && !isNaN(newHours)) {
                            addHours(index, parseInt(newHours, 10));
                          }
                        }}
                      >
                        +
                      </button>
                      <div className="hours-circles">
                        {hours[index].map((entry, i) => (
                          <div
                            key={i}
                            className="hours-circle"
                            style={{ backgroundColor: entry.color }}
                          >
                            {entry.hours}
                          </div>
                        ))}
                      </div>
                    </div>
                  </td>
                );
              })}
              <td>
                {isWeekend(rowIndex * 5 + columns.length) ? (
                  <span>Weekend</span>
                ) : (
                  <FontAwesomeIcon icon={faSmile} />
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CalendarTable;
