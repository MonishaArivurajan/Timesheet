import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import './Emp.css';

const Emp = () => {
  const { empId } = useParams();
  const [employee, setEmployee] = useState(null);
  const [leaveDays, setLeaveDays] = useState(0);
  const [timesheet, setTimesheet] = useState([]);
  const [monthlySalary, setMonthlySalary] = useState(0);
  const [employeeDetail, setEmployeeDetail] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch employee details including the joining date and timesheet
    axios.get(`http://127.0.0.1:8000/api/employee-details/${empId}/`)
      .then(response => {
        const user = response.data;
        const timesheetData = user.timesheet || [];
        const joiningDate = user.joining_date;
       
        setEmployee(user);
        setTimesheet(timesheetData);
        calculateLeaveDaysAndSalary(timesheetData, joiningDate);
        
        
      })
      .catch(error => {
        console.error('Error fetching employee details:', error);
        
      });
  }, [empId]);

  
  useEffect(() => {
    if (empId) {
      axios.get(`http://127.0.0.1:8000/api/employee-details/${empId}/`)
        .then(response => {
          setEmployeeDetail(response.data);
          setLoading(false);
        })
        .catch(error => {
          setError('There was an error fetching the employee details.');
          setLoading(false);
        });
    }
  }, [empId]);
 
const calculateLeaveDaysAndSalary = (timesheetData, joiningDate) => {
    const getSundaysInMonth = (year, month) => {
      let date = new Date(year, month, 1);
      const sundays = [];
      while (date.getMonth() === month) {
        if (date.getDay() === 0) { // Sunday
          sundays.push(date.getDate());
        }
        date.setDate(date.getDate() + 1);
      }
      return sundays;
    };
    

    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth(); // 0-indexed
    const sundays = getSundaysInMonth(currentYear, currentMonth);
    const totalDays = new Date(currentYear, currentMonth + 1, 0).getDate();
    const workingDays = totalDays - sundays.length;

    const filteredTimesheet = timesheetData.filter(entry => {
      const entryDate = new Date(entry.date);
      return entryDate >= new Date(joiningDate) && 
        entryDate.getMonth() === currentMonth && 
        entryDate.getFullYear() === currentYear;
    });
    console.log("Filtered Timesheet:", filteredTimesheet);

    const filledDays = filteredTimesheet.map(entry => new Date(entry.date).getDate());
    const uniqueFilledDays = new Set(filledDays);
    const filledWorkingDays = [...uniqueFilledDays].filter(day => !sundays.includes(day)).length;
    console.log("Filled Working Days:", filledWorkingDays);
    const leaveDaysCount = workingDays - filledWorkingDays;
    setLeaveDays(leaveDaysCount);
    
    const fixedMonthlySalary=[];
    const salary = workingDays > 0 && !isNaN(fixedMonthlySalary) && fixedMonthlySalary > 0
      ? (filledWorkingDays / workingDays) * fixedMonthlySalary
      : 0;
    console.log("salary",salary);
    setMonthlySalary(salary.toFixed(2));
  };
  

  if (!employee) {
    return <p>Loading...</p>;
  }

  return (
    <div className="employee-details">
      <p>Welcome, {employee.emp_id}</p>
      <p>Leave Days: {leaveDays}</p>
      <p>Monthly Salary: ₹{monthlySalary}</p><br/>
      <h3>Timesheet Details</h3>
      <table>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Date</th>
            <th>Total Working Hours</th>
          </tr>
        </thead>
        <tbody>
             <tr>
              <td>{employeeDetail.employee_name}</td>
              <td>{employeeDetail.date}</td>
              <td>{employeeDetail.total_hours_worked}</td>
            </tr>
          
        </tbody>
      </table>
      {error && <p className="error-message">{error}</p>}
    </div>
  );
};

export default Emp;
