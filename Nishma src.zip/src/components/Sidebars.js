import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClock, faHome, faFileAlt, faChartBar, faTasks, faStar, faUsers, faDollarSign, faCogs } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import './Sidebars.css';

const Sidebars = ({ onCalendarClick }) => {
  return (
    <div className="sidebar">
      <div className="sidebar-title">
        <FontAwesomeIcon icon={faClock} />
        <span>TIME TITANS</span>
      </div>
      <div className="sidebar-search">
        <input type="text" placeholder="Search..." />
      </div>
      <div className="sidebar-menu">
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faHome} />
          <span><Link to="/dashboard/profile" className="sidebar-link">Profile</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faFileAlt} />
          <span><Link to="/dashboard/update-timesheet" className="sidebar-link">Add Timesheet</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faChartBar} />
          <span><Link to="/dashboard/view-timesheet" className="sidebar-link">View Timesheet</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faTasks} />
          <span><Link to="/dashboard/calendar" className="sidebar-link">Calendar</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faStar} />
          <span><Link to="/dashboard/teamtable" className="sidebar-link">Team Table</Link></span>
        </div>
      </div>
      <button className="timesheet-button" onClick={onCalendarClick}>TIMESHEET</button>
    </div>
  );
};

export default Sidebars;
