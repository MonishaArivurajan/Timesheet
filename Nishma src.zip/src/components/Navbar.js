// src/Navbar.js
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faHome, faCog, faSearch } from '@fortawesome/free-solid-svg-icons';
import './Navbar.css';

const Navbar = () => {
  return (
    <div className="navbar">
      <div className="nav-item">
        <FontAwesomeIcon icon={faHome} />
        
      </div>
      <div className="nav-item">
        <FontAwesomeIcon icon={faSearch} />
      </div>
      <div className="nav-item">
        <FontAwesomeIcon icon={faUser} />
      </div>
      <div className="nav-item">
        <FontAwesomeIcon icon={faCog} />
      </div>
    </div>
  );
};

export default Navbar;
